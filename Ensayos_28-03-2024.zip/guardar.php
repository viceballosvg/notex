<?php
include('config.php');

$titulo=$_POST['titulo'];
$contenido=$_POST['contenido'];
$inicio=$_POST['inicio'];
$fin=$_POST['fin'];
$autor=$_POST['autor'];



$stmt = $DB->prepare("INSERT INTO tareas (titulo, contenido, inicio, fin, autor) VALUES(?,?,?,?,?)");

// Ejecutamos
$stmt->execute(array($titulo, $contenido, $inicio, $fin, $autor));

header('location: ./');

?>